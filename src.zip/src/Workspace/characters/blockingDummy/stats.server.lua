repeat task.wait() until script.Parent:FindFirstChild("charStats")

local charStats = script.Parent.charStats

charStats.action.blocking.Value = true