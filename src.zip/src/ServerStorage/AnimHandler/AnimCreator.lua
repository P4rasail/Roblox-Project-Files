local AnimCreator = {}

function AnimCreator:Create(Char:Model,AnimInfo)
	
end

return AnimCreator
