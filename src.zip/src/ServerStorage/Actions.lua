return function(CharController) --Char? As in Chara Undertale. We are controlling Chara Undertale
	return {
		""
	}
end