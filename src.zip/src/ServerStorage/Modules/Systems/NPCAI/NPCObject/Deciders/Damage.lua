return function(NPCObject)
	
	local CharConfig = NPCObject.CharConfig
	local Data = CharConfig.Data
	for i,v in Data.HitBy do
		
	end
end