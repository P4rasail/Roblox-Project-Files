local repStorage = game:GetService("ReplicatedStorage")

local Modules = repStorage.Modules

local Gui3d = require(Modules.gameModules.Gui3d)


Gui3d.connectGUIPart("Menu",true)