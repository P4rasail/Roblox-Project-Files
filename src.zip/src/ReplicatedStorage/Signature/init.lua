--[[
   Creator:Paras/P4rasail
   KANYE WEST
   Date: Current Year/Current Month/Current Day
   Description:[Module Description]
   Functions:[All Module Functions]
    Example:[Module Example]

local Signature = {}

-- Function Description
function Signature:Function([Args])
    -- Explanation of function
end
try


-- Example Usage:
-- Examples of using this module
return Signature

]]