local Server = {}

function Server:PlayEffects(CharConfig,Options)
	
end

if not Server.Running then
	Server.Running = true
	
end

return Server
