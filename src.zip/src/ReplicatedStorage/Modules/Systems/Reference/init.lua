local Conditions = {}

return Conditions
