return {
	AllowedActions = {
		"Flight"
	}
}