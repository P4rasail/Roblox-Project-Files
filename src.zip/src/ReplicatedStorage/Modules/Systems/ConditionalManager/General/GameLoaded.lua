
return function()
	return _G.Loaded
	end
