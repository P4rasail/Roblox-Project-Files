local RepStorage = game:GetService("ReplicatedStorage")

local Indexes = require(RepStorage:WaitForChild("Indexes"))



local GUIManager = {}

if not GUIManager.Running then
	GUIManager.Running = true
end




return GUIManager
