

return {
	ReplicatedStorage = {
		{
			"Events"
		},
		"Models"
	}
}