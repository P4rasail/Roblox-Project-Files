task.spawn(function()
	script.Parent.Sound:Play()
end)