return {
	GettingHit = false,
	Flight = {
		IsFlying = false,
		ShiftFlying = false,
		
	},
	KeysPressed = {
		W = false,
		A = false,
		S = false,
		D = false,
		Space = false,
		LeftControl = false
	},
	MovementMode = "Idle",
	HitBy = {},
	Stuns = {},
	Debounces = {},
	Combo = {}
}
