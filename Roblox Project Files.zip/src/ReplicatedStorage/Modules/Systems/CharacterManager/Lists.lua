local Lists = {
	Chars = {},
	Data = {}
}


return Lists
