return {
	Keyboard = function(Input,TypeEntry)
		if Input.Key == TypeEntry.Key then
			return true 
			
		end
		return false
	end,
}