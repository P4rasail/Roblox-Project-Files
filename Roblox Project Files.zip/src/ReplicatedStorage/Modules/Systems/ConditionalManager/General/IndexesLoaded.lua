local Indexes = require(game:GetService("ReplicatedStorage"):WaitForChild("Indexes"))

return function()
	return Indexes.Loaded
	end
