
return function(CharConfig)
	if not CharConfig then return end
	return CharConfig.Flying
	end
