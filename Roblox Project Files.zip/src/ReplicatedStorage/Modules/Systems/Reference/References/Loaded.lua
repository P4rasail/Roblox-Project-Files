return function(Entry)
	
end