local Evaluator = {}

function Evaluator:Evaluate(CharConfig,ComboTable)
	if not CharConfig or not ComboTable then return end
	
end

return Evaluator
