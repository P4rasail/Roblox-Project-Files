return function(Array)
	local Lists = {}
	
	
	function Lists:Create()
		
	end
end